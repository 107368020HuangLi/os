package com.example.mycomputer.final_project_v2;


import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{

    public MainActivity(){
        mainActivity = this;
    }

    private MediaPlayer mp = new MediaPlayer();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        tvscore = (TextView) findViewById(R.id.tvscore);
        tvbestscore = (TextView) findViewById(R.id.tvbestscore);
        animal = (Animal)findViewById(R.id.Animal);
        game2 = (game2) findViewById(R.id.game2);

        jump = (Button) findViewById(R.id.jump);
        jump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                game2.start();
            }
        });

        final MediaPlayer mp = MediaPlayer.create(this,R.raw.music);
        mp.start();
        mp.setLooping(true);
    }

    Vibrator vb;

    public void onClick(DialogInterface.OnClickListener v) {
        vb.vibrate(1000);
    }


    public  void  clearscore(){
        score = 0;
        showscore();
    }

    public  void  showscore(){
        tvscore.setText(score+"");
        tvscore.setTextSize(24);
    }
    public void  addscore(int s){
        score+=s;
        showscore();

        int maxscore = Math.max(score,getBestscore());
        savebestscore(maxscore);
        showbestscore(maxscore);
    }

    public void savebestscore(int s){
        SharedPreferences.Editor e = getPreferences(MODE_PRIVATE).edit();
        e.putInt(SP_KEY_BEST_SCORE,s);
        e.commit();
    }

    public int getBestscore(){
        return getPreferences(MODE_PRIVATE).getInt(SP_KEY_BEST_SCORE,0);
    }

    public void showbestscore(int s){
        tvbestscore.setText(s+"");
        tvbestscore.setTextSize(24);
    }

    public Animal getAnimal() {
        return animal;
    }

    private  int score=0;
    private  TextView tvscore,tvbestscore;
    private game2 game2;
    private Animal animal = null;
    private  static MainActivity mainActivity = null;

    private Button jump;


    public  static  MainActivity getMainActivity(){
        return mainActivity;
    }

    public static final String SP_KEY_BEST_SCORE = "bestscore";


}
