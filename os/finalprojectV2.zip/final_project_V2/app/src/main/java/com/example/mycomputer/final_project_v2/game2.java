package com.example.mycomputer.final_project_v2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Point;
import android.os.Vibrator;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.GridLayout;

import java.util.ArrayList;
import java.util.List;

public class game2 extends GridLayout {

    public game2(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public game2(Context context) {
        super(context);
        init();
    }

    public game2(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }


    private  void init(){

        setColumnCount(4);
        setBackgroundColor(0xffbbada0);
        setOnTouchListener(new View.OnTouchListener() {

            private float startX,startY,finalX,finalY;

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                switch (motionEvent.getAction()){

                    case MotionEvent.ACTION_DOWN:
                        startX = motionEvent.getX();
                        startY = motionEvent.getY();
                        break;

                    case MotionEvent.ACTION_UP:
                        finalX = motionEvent.getX()-startX;
                        finalY = motionEvent.getY()-startY;

                        if(Math.abs(finalX)>Math.abs(finalY)){
                            if(finalX<-5){
                                swipe_left();
                            }
                            else if (finalX>5){
                                swipe_right();
                            }
                        }else{
                            if(finalY<-5){
                                swipe_up();
                            }else if (finalY>5){
                                swipe_down();
                            }
                        }
                        break;
                }
                return true;
            }
        });
    }

    @Override
    protected void onSizeChanged( int w, int h, int oldw, int oldh ){
        super.onSizeChanged( w, h, oldw, oldh);
        Config.CARD_WIDTH = (Math.min(w,h)-10)/Config.LINES;
        addcard(Config.CARD_WIDTH,Config.CARD_WIDTH);

        start();
    }

    private void addcard(int cardWidth,int cardHeight){
        card c;
        for(int y=0; y<4 ; y++){
            for (int x=0 ; x<4 ; x++){
                c=new card(getContext());
                c.setNum(0);
                addView(c, cardWidth,cardHeight);

                cardsMap[x][y] = c ;
            }
        }
    }

    void start(){

        MainActivity  aty = MainActivity.getMainActivity();
        aty.clearscore();
        aty.savebestscore(aty.getBestscore());

        for( int y =0 ; y <4 ; y++){
            for ( int x =0 ; x< 4 ; x++){
                cardsMap[x][y].setNum(0);
            }
        }

        addRandomNum();
        addRandomNum();
    }

    private void addRandomNum(){

        emptyPoint.clear();

        for(int y=0 ; y < 4 ; y++ ){
            for (int x = 0 ; x<4 ;x++){
                if(cardsMap[x][y].getNum()<=0){
                    emptyPoint.add(new Point(x,y));
                }
            }
        }

        if(emptyPoint.size()>0) {
            Point p = emptyPoint.remove((int) (Math.random() * emptyPoint.size()));
            cardsMap[p.x][p.y].setNum(Math.random() > 0.1 ? 2 : 4);  //   0.1>x>0 是 2 , 1.0 > x > 0.1 是 4 ;  9:1的比率

            MainActivity.getMainActivity().getAnimal().createscale(cardsMap[p.x][p.y]);
        }
    }


    private void swipe_left(){
        //  setBackgroundColor(0xffffff99);
        boolean more = false;

        for( int y =0 ; y <4 ; y++){
            for ( int x =0 ; x< 4 ; x++){

                for(int x1 = x+1 ; x1 <4 ; x1++){
                    if (cardsMap[x1][y].getNum()>0){

                        if(cardsMap[x][y].getNum()<=0){

                            MainActivity.getMainActivity().getAnimal().createAnimal(cardsMap[x1][y],cardsMap[x][y],x1,x,y,y);

                            cardsMap[x][y].setNum(cardsMap[x1][y].getNum());
                            cardsMap[x1][y].setNum(0);

                            x--;
                            more =true;
                        }else if(cardsMap[x][y].equals(cardsMap[x1][y])) {

                            MainActivity.getMainActivity().getAnimal().createAnimal(cardsMap[x1][y],cardsMap[x][y],x1,x,y,y);

                            cardsMap[x][y].setNum(cardsMap[x][y].getNum()*2);
                            cardsMap[x1][y].setNum(0);

                            MainActivity.getMainActivity().addscore(cardsMap[x][y].getNum());
                            more =true;
                        }
                        break;
                    }
                }
            }
        }

        if(more){
            addRandomNum();
            check();
        }
    }

    private void swipe_right(){
        //   setBackgroundColor(0xffb0e0e6);

        boolean more = false;

        for( int y = 0 ; y <4 ; y++){
            for ( int x = 3  ; x > 0 ; x-- ){

                for(int x1 = x-1 ; x1 >= 0 ; x1--){
                    if (cardsMap[x1][y].getNum()>0){

                        if(cardsMap[x][y].getNum()<=0){
                            MainActivity.getMainActivity().getAnimal().createAnimal(cardsMap[x1][y],cardsMap[x][y],x1,x,y,y);
                            cardsMap[x][y].setNum(cardsMap[x1][y].getNum());
                            cardsMap[x1][y].setNum(0);

                            x++;
                            more =true;
                        }else if(cardsMap[x][y].equals(cardsMap[x1][y])) {
                            MainActivity.getMainActivity().getAnimal().createAnimal(cardsMap[x1][y],cardsMap[x][y],x1,x,y,y);
                            cardsMap[x][y].setNum(cardsMap[x][y].getNum()*2);
                            cardsMap[x1][y].setNum(0);
                            MainActivity.getMainActivity().addscore(cardsMap[x1][y].getNum());
                            more =true;
                        }
                        break;
                    }
                }
            }
        }

        if(more){
            addRandomNum();
            check();
        }
    }

    private void swipe_up(){
        //  setBackgroundColor(0xff006400);
        boolean more = false;

        for( int x = 0  ; x < 4 ; x++ ){
            for ( int y = 0 ; y < 4 ; y++){

                for(int y1 = y+1 ; y1 < 4 ; y1++){
                    if (cardsMap[x][y1].getNum()>0){

                        if(cardsMap[x][y].getNum()<=0){

                            MainActivity.getMainActivity().getAnimal().createAnimal(cardsMap[x][y1],cardsMap[x][y],x,x,y1,y);

                            cardsMap[x][y].setNum(cardsMap[x][y1].getNum());
                            cardsMap[x][y1].setNum(0);

                            y--;
                            more =true;
                        }else if(cardsMap[x][y].equals(cardsMap[x][y1])) {

                            MainActivity.getMainActivity().getAnimal().createAnimal(cardsMap[x][y1],cardsMap[x][y],x,x,y1,y);

                            cardsMap[x][y].setNum(cardsMap[x][y].getNum()*2);
                            cardsMap[x][y1].setNum(0);
                            MainActivity.getMainActivity().addscore(cardsMap[x][y].getNum());
                            more =true;
                        }
                        break;
                    }
                }
            }
        }

        if(more){
            addRandomNum();
            check();
        }
    }

    private void swipe_down(){
        //setBackgroundColor(0xffdda0dd);

        boolean more = false;

        for( int x = 0  ; x < 4 ; x++){
            for ( int y = 3 ; y >=0 ; y--){

                for(int y1 = y-1 ; y1 >=0 ; y1--){
                    if (cardsMap[x][y1].getNum()>0){

                        if(cardsMap[x][y].getNum()<=0){

                            MainActivity.getMainActivity().getAnimal().createAnimal(cardsMap[x][y1],cardsMap[x][y],x,x,y1,y);

                            cardsMap[x][y].setNum(cardsMap[x][y1].getNum());
                            cardsMap[x][y1].setNum(0);

                            y++;
                            more =true;
                        }else if(cardsMap[x][y].equals(cardsMap[x][y1])) {

                            MainActivity.getMainActivity().getAnimal().createAnimal(cardsMap[x][y1],cardsMap[x][y],x,x,y1,y);

                            cardsMap[x][y].setNum(cardsMap[x][y].getNum()*2);
                            cardsMap[x][y1].setNum(0);
                            MainActivity.getMainActivity().addscore(cardsMap[x][y].getNum());
                            more =true;
                        }
                        break;
                    }
                }
            }
        }

        if(more){
            addRandomNum();
            check();
        }
    }
    private void check(){

        boolean complete = true ;
        ALL:
        for (int y = 0 ; y< 4 ; y++){
            for(int x = 0 ; x < 4; x++){
                if(cardsMap[x][y].getNum()==0 ||
                        (x > 0 && cardsMap[x][y].equals(cardsMap[x-1][y])) ||
                        (x < 3 && cardsMap[x][y].equals(cardsMap[x+1][y])) ||
                        (y > 0 && cardsMap[x][y].equals(cardsMap[x][y-1])) ||
                        (y < 3 && cardsMap[x][y].equals(cardsMap[x][y+1]))) {
                    complete = false;
                    break ALL;
                }
            }
        }

        if (complete){
            new AlertDialog.Builder(getContext()).setTitle("Remind").setMessage("Game Over").setPositiveButton("Comform", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.getMainActivity().onClick(this);
                    start();
                }
            }).show();
        }
    }
    private card[][] cardsMap = new card[4][4];
    private List<Point> emptyPoint = new ArrayList<Point>();





/*
    public boolean onTouch(View view, MotionEvent motionEvent) {
        Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        if(motionEvent.getAction() == MotionEvent.ACTION_DOWN){
            vb.vibrate(3000);
        }else if(motionEvent.getAction() == MotionEvent.ACTION_UP){
            vb.cancel();
        }
        return true;
    }
    */

}