package com.example.mycomputer.final_project_v2;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;

public class Animal extends FrameLayout {

    public Animal(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initAnim();
    }

    public Animal(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initAnim();
    }

    public Animal(@NonNull Context context) {
        super(context);
        initAnim();
    }

    private void initAnim(){

    }

    public void createAnimal(final card from,final card to,int fromX,int toX,int fromY,int toY){

        final card c = getcard(from.getNum());
        LayoutParams lp = new LayoutParams(Config.CARD_WIDTH,Config.CARD_WIDTH);
        lp.leftMargin = fromX*Config.CARD_WIDTH;
        lp.topMargin = fromY*Config.CARD_WIDTH;
        c.setLayoutParams(lp);

        if(to.getNum()<=0){
            to.getLabel().setVisibility(View.INVISIBLE);
        }
        TranslateAnimation ta = new TranslateAnimation(0,Config.CARD_WIDTH*(toX-fromX),0,Config.CARD_WIDTH*(toY-fromY));
        ta.setDuration(100);
        ta.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                to.getLabel().setVisibility(View.VISIBLE);
                recyclecard(c);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        c.startAnimation(ta);
    }

    private card getcard(int num){
        card c;
        if(cards.size()>0){
            c = cards.remove(0);
        }else {
            c = new card(getContext());
            addView(c);
        }
        c.setVisibility(View.VISIBLE);
        c.setNum(num);
        return c;
    }

    private void recyclecard(card c){
        c.setVisibility(View.INVISIBLE);
        c.setAnimation(null);
        cards.add(c);
    }

    private List<card> cards = new ArrayList<card>();

    public void createscale(card targe){                                     //產生方塊由小到大
        ScaleAnimation sa = new ScaleAnimation(0.1f,1,0.1f,1,Animation.RELATIVE_TO_SELF,0.5f);
        sa.setDuration(50);
        targe.setAnimation(null);
        targe.getLabel().startAnimation(sa);
    }
}
