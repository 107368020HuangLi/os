package com.example.mycomputer.final_project_v2;

public class Config {
    public static final int LINES = 4;
    public static int CARD_WIDTH = 0;
}
