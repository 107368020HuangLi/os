package com.example.mycomputer.final_project_v2;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

public class card extends FrameLayout {

    public card(Context context) {
        super(context);
        label = new TextView(getContext());
        label.setTextColor(0xffFF3EFF);
        label.setTextSize(18);
        //changeColor();
        label.setGravity(Gravity.BOTTOM);
        LayoutParams lp = new LayoutParams(-1,-1);
        lp.setMargins(10,10,0,0);
        addView(label,lp);
        setNum(0);
    }



    private int num = 0 ;

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;

        if (num <= 0) {
            label.setText("");
        } else {
            label.setText(num + "");
        }

        switch (num){
            case 2:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.rat));
                break;
            case 4:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.ox));
                break;
            case 8:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.tiger));
                break;
            case 16:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.rabbit));
                break;
            case 32:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.dragon));
                break;
            case 64:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.snake));
                break;
            case 128:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.horse));
                break;
            case 256:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.goat));
                break;
            case 512:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.monkey));
                break;
            case 1024:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.chicken));
                break;
            case 2048:
                label.setBackgroundDrawable(getResources().getDrawable(R.drawable.dog));
                break;
            default:
                label.setBackgroundColor(0xffF5DEB3);
        }
    }

    public boolean equals(card o) {
        return getNum()==o.getNum();
    }
    public TextView getLabel() {
        return label;
    }

    private TextView label;
}
